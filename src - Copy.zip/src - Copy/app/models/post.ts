export interface Post {
    id:Number;
    userId:Number;
    title:String;
   body:String;
}
